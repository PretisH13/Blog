from django.contrib import admin
from .models import Landingpage


admin.site.register(Landingpage)
